int f(int x)
{
    return 10;
}

int main()
{
    return f(11)+7;
}

